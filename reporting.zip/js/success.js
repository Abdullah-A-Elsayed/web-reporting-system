var success = document.getElementById('success').innerHTML;
success = success.trim();
if (success) {
	alert(success);
}