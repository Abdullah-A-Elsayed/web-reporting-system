<?php
		define("HOST","mysql.hostinger.co.uk");
		define("USERNAME","u795344082_aly");
		define("PASSWORD","aly@57357");
		define("DBNAME","u795344082_aly57");
		/*

Client ID: 21594441
Email: abdullah.ali26@hotmail.com
First Name: Abdullah
Last Name: El-Saied
Country: Egypt
Phone: + 20 - 1001917452
Company: Abdullah El-Saied
Status: Active
Member since: 02/08/2017

		*/
?>