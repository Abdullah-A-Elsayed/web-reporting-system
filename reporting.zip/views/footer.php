<div id="footer">
      <div class="container">
        <p class="muted credit">developed by <a target="_blank" href="https://www.facebook.com/be.cool2015">Abdullah</a> © 2017</p>
      </div>
</div>